#include <iostream>
#include <ctime>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <windows.h>
using namespace std;
const int N = 110;
int maxprof[N];
int eachprof[N];
int distribution[N][N];
const int n=30,m=10;
void betterDynamic(int n, int i)
{
    for (int j = n; j >= 1; j--)
    {
        int MAX = 0;
        for (int k = j; k >= 0; k--)
        {
            if (MAX < maxprof[k] + eachprof[j - k])
            {
                MAX = maxprof[k] + eachprof[j - k];
                maxprof[j] = MAX;
                distribution[i][j] = j - k;
            }
        }
    }
}
int main()
{
    srand(int(NULL));
    cout << n << "̨�豸"
         << " " << m << "�䳵��" << endl;

    LARGE_INTEGER large_interger1, large_interger2;
    double dff1;
    __int64 c1, c2;
    QueryPerformanceFrequency(&large_interger1);
    dff1 = large_interger1.QuadPart;
    QueryPerformanceCounter(&large_interger1);
    c1 = large_interger1.QuadPart;

    for (int i = 1; i <= m; i++)
    {
        for (int j = 1; j <= n; j++)
            eachprof[j] = eachprof[j - 1] + rand() % 1000;

        betterDynamic(n, i);
    }
    QueryPerformanceCounter(&large_interger1);
    c2 = large_interger1.QuadPart;
    printf("����Ҫ��ʱ��%8.3lfms\t\n\n", (c2 - c1) * 1000 / dff1);

    puts("���䷽����Ϊ");
    int k = n;
    for (int i = m; i >= 1; i--)
    {
        cout << "(" << i << "," << distribution[i][k] << ")" << endl;
        k = k - distribution[i][k];
    }
    puts("");

    cout<<endl<<"�����(��i��j�б�ʾj̨���豸��i�ų�����������)��"<<endl;
    for (int i = 1; i <= n; i++)
    cout << eachprof[i] << " ";
    cout << endl<<endl;

    puts("�������Ϊ");
    for (int i = 1; i <= n; i++)
    cout << maxprof[i] << " ";
    cout << endl<<endl;

    system("pause");
    return 0;
}
