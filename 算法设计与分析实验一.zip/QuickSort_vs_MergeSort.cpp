#include<iostream>
#include<cstdlib>
#include<ctime>
#include<cstdio>
#include<iomanip>
#include<fstream>
#include <windows.h>
using namespace std;
const int N=1e6+10;
const int M=1e5;
int n=1;
int a[N];
int temp[N];
int b[N];
clock_t startTime,endTime,startTime1,endTime1;
void Menu() {
	cout << "-----------�˵�----------" << endl;
	cout << "*    1.�ֹ���������     *"<< endl;
	cout << "*    2.�����������     *"<< endl;
	cout << "-------------------------" << endl;
}

int SPLIT(int a[],int low,int high) {
	int i=low;
	int temp;
	if(a[low]<a[high+low>>1]) {
		if(a[low]<a[high]) {
			if(a[high+low>>1]<a[high]) {
				//�������� low+high >>1
				temp=a[low+high>>1];
				a[low+high>>1]=a[low];
				a[low]=temp;
			}
			//�������� high
			else {
				temp=a[high];
				a[high]=a[low];
				a[low]=temp;
			}
		}
	} else {
		if(a[high]>a[high+low>>1]) {
			if(a[low]>a[high])
				//��������a[high]
			{
				temp=a[high];
				a[high]=a[low];
				a[low]=temp;

			}
		}
		//�������� a[low+high>>1]
		else {
			temp=a[low+high>>1];
			a[low+high>>1]=a[low];
			a[low]=temp;
		}
	}
	for(int j=low+1; j<=high; j++) {
		if(a[j]<=a[low]) {
			i++;
			if(i!=j) {
				temp=a[j];
				a[j]=a[i];
				a[i]=temp;
			}
		}
	}
	temp=a[low];
	a[low]=a[i];
	a[i]=temp;
	return i;
}
void QUICKSORT(int a[], int low, int high) {
	if(low<high) {
		int w=SPLIT(a,low,high);
		QUICKSORT(a,low,w-1);
		QUICKSORT(a,w+1,high);
	}
}
void MERGE(int a[],int l,int mid,int high) {
	int l1=l,l2=mid+1;
	int cnt=0;
	while(l1<=mid&&l2<=high) {
		if(a[l1]<a[l2])
			temp[cnt++]=a[l1++];
		else temp[cnt++]=a[l2++];
	}
	while(l1<=mid)
		temp[cnt++]=a[l1++];
	while(l2<=high)
		temp[cnt++]=a[l2++];
	for(int i=l,j=0; i<=high ; i++,j++)
		a[i]=temp[j];
}
void MERGESORT(int a[],int l,int r) {
	if(l>=r) return ;
	int mid=l+r>>1;
	MERGESORT(a,l,mid);
	MERGESORT(a,mid+1,r);
	MERGE(a,l,mid,r);
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	//ofstream os("data.txt",ios::out);
	ifstream in("data.txt",ios::in);
	Menu();
	srand(int(NULL));
	puts("��ѡ����������ģʽ");
	int flag;
	cin>>flag;
	printf("�������\t�鲢�����㷨ʱ��\t���������㷨ʱ��\n");
	if(flag==1) {
			while(n<=20) {
			for(int i=0; i<5000*n; i++) {
				in>>a[i];
				b[i]=a[i];
			}
			LARGE_INTEGER  large_interger1, large_interger2;
			double dff1, dff2;
			__int64  c1, c2, c3, c4;
			QueryPerformanceFrequency(&large_interger1);
			dff1 = large_interger1.QuadPart;
			QueryPerformanceCounter(&large_interger1);
			c1 = large_interger1.QuadPart;
			MERGESORT(a,0,5000*n-1);
			QueryPerformanceCounter(&large_interger1);
			c2 = large_interger1.QuadPart;
			printf("%d\t\t%8.3lfms\t\t",n*5000,(c2-c1)*1000/dff1);

			QueryPerformanceFrequency(&large_interger2);
			dff2 = large_interger2.QuadPart;
			QueryPerformanceCounter(&large_interger2);
			c3 = large_interger2.QuadPart;
			QUICKSORT(b,0,5000*n-1);
			QueryPerformanceCounter(&large_interger2);
			c4 = large_interger2.QuadPart;
			printf("%8.3lfms\n",(c4-c3)*1000/dff1);
			n++;
		}
		
	} else if(flag==2) {
		while(n<=20) {
			for(int i=0; i<5000*n; i++) {
				a[i]=rand()%M;
				b[i]=a[i];
				//os<<a[i]<<" ";
			}
			LARGE_INTEGER  large_interger1, large_interger2;
			double dff1, dff2;
			__int64  c1, c2, c3, c4;
			QueryPerformanceFrequency(&large_interger1);
			dff1 = large_interger1.QuadPart;
			QueryPerformanceCounter(&large_interger1);
			c1 = large_interger1.QuadPart;
			MERGESORT(a,0,5000*n-1);
			QueryPerformanceCounter(&large_interger1);
			c2 = large_interger1.QuadPart;
			printf("%d\t\t%8.3lfms\t\t",n*5000,(c2-c1)*1000/dff1);

			QueryPerformanceFrequency(&large_interger2);
			dff2 = large_interger2.QuadPart;
			QueryPerformanceCounter(&large_interger2);
			c3 = large_interger2.QuadPart;
			QUICKSORT(b,0,5000*n-1);
			QueryPerformanceCounter(&large_interger2);
			c4 = large_interger2.QuadPart;
			printf("%8.3lfms\n",(c4-c3)*1000/dff1);

			n++;
		}
	}
	return 0;
}
